KantanDocGenTool utilises The Saxon XSLT and XQuery Processor from Saxonica Limited, under the same MPL 2.0 license as KantanDocGenTool itself.
http://www.saxonica.com/
Saxon .NET HE source code can be obtained via http://www.saxonica.com/documentation/#!dotnet.
