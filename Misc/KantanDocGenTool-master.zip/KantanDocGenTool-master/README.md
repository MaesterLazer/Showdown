KantanDocGenTool
-------------

This tool should be included in the UE4 engine directory.

If using source, the repo should be created in the directory Engine/Source/Programs/KantanDocGenTool

