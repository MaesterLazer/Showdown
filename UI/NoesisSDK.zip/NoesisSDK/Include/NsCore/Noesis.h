////////////////////////////////////////////////////////////////////////////////////////////////////
// NoesisGUI - http://www.noesisengine.com
// Copyright (c) 2013 Noesis Technologies S.L. All Rights Reserved.
////////////////////////////////////////////////////////////////////////////////////////////////////


#ifndef __CORE_NOESIS_H__
#define __CORE_NOESIS_H__


#include <stdint.h>


#include <NsCore/BuildSettings.h>
#include <NsCore/CompilerSettings.h>
#include <NsCore/PlatformSettings.h>
#include <NoesisLicense.h>


#endif
